# governors_gui
Aplicación que permite configurar los distintos governors de manera sencilla.

El GUI hace uso de la aplicación **cpufreq** (por lo que es necesaria tenerla instalada). La misma nos permite cambiar la velocicudad del procesador dentro de los parámetros dentro de los que este funciona normalmente.

> No es una aplicación para realizar *overclocking*.

Una de las opciones que más me gusta de este programa es la de poder cambiar los **"governors"** disponibles. 
Los mismos serían algo así como **esquemas de potencia del CPU preconfigurados**.

El GUI que aquí se presenta permite configurar dichos governors (siempre y cuando esten soportados por el procesador) para la cantidad de **núcleos** que uds. elijan.

> El GUI también muestra cuales son los *governors* soportados por el CPU.

Espero les sirva, para más información pueden visitar: https://thenerdyapprentice.blogspot.com

Saludos!.
